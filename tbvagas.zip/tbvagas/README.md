# TBVAGAS AI - Monitoramento e Mapeamento Inteligente de Estacionamento

Sistema de Visão Computacional de nível profissional para detecção de disponibilidade de vagas de estacionamento utilizando **OpenCV** e **Inteligência Artificial (YOLOv8)**.

O projeto inclui um **Dashboard Web Interativo** com mapeamento poligonal de vagas em perspectiva via HTML5 Canvas, esteira de processamento de imagem em tempo real, suporte a múltiplas imagens/câmeras e uma ferramenta **CLI de Linha de Comando**.

---

## 🚀 Principais Funcionalidades

1. **Detecção Inteligente de Vagas Ocupadas vs. Livres**:
   - **Pipeline OpenCV Clássico**: Conversão em escala de cinza, filtro Gaussiano, *Adaptive Thresholding* (invariante a variações drásticas de iluminação e sombras), dilatação morfológica, detector de bordas *Canny* e cálculo de variância/desvio padrão de luminância.
   - **Modo IA com YOLOv8**: Detecção profunda de veículos (carros, caminhões, ônibus, motos) com teste de contenção em polígonos.
   - **Modo Híbrido**: Fusão de sensores (OpenCV + IA) para máxima confiabilidade tanto de dia quanto à noite.

2. **Mapeamento Interativo de Vagas (Studio)**:
   - Suporte a **Polígonos de 4 Pontos** (quadriláteros de perspectiva real) e caixas retangulares.
   - Vértices arrastáveis em tempo real para ajuste fino dos ângulos das vagas.
   - Categorização de vagas: *Normal, PCD (Acessibilidade), Idoso, Moto, Carga e Descarga*.
   - Persistência automática em `data/spots.json`.

3. **Gerenciador de Imagens**:
   - Upload de novas imagens via *Drag & Drop* ou seleção de arquivos.
   - Galeria com miniaturas e contagem de vagas.
   - Análise instantânea de qualquer imagem enviada.

4. **Visualização Executiva**:
   - Painel Glassmorphic com contadores em tempo real (Total, Livres, Ocupadas, % Ocupação).
   - Overlay translúcido de alta definição sobreposto à imagem (Verde = Livre, Vermelho = Ocupada).
   - Exportação de relatório em JSON e download direto da imagem anotada pelo OpenCV.

---

## 📁 Estrutura do Projeto

```text
tbvagas/
├── app.py                     # Servidor Web Flask e API REST
├── cli_analyzer.py            # Ferramenta CLI para processamento direto no terminal
├── config.py                  # Parâmetros padrão, thresholds e diretórios
├── requirements.txt           # Dependências do projeto
├── README.md                  # Documentação completa
├── core/
│   ├── __init__.py
│   ├── detector.py            # Motor de visão computacional (OpenCV + YOLO)
│   ├── spot_manager.py        # Gerenciamento de polígonos, geometria e persistência
│   └── image_manager.py       # Leitura, validação e upload de imagens
├── templates/
│   └── index.html             # Interface web executiva
├── static/
│   ├── css/
│   │   └── style.css          # Design system dark moderno e responsivo
│   └── js/
│       └── app.js             # Engine de canvas, zoom/pan e comunicação REST
└── data/
    ├── images/                # Diretório de armazenamento de imagens
    └── spots.json             # Definição dos polígonos das vagas mapeadas
```

---

## 🛠️ Como Executar

### 1. Iniciar a Interface Web Completa (Recomendado)

```powershell
python app.py
```

Abra seu navegador em: **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

Na interface web você pode:
- Alternar entre **Monitoramento** e **Mapeamento de Vagas** no topo.
- Arrastar ou clicar em **Adicionar Imagem** para testar fotos de qualquer estacionamento.
- Ajustar a sensibilidade do threshold no slider lateral.
- Alternar o motor de detecção entre *Híbrido*, *OpenCV Clássico* ou *YOLOv8*.

---

### 2. Executar via Terminal / CLI (`cli_analyzer.py`)

Você também pode rodar análises diretamente pela linha de comando:

```powershell
# Analisar a imagem demarcada gerada
python cli_analyzer.py --image Gemini_Generated_Image_12iqg312iqg312iq.jpg

# Analisar todas as imagens cadastradas em lote
python cli_analyzer.py --all

# Analisar a imagem noturna usando OpenCV clássico com métricas detalhadas
python cli_analyzer.py --image estacionamento_noturno.jpg --mode opencv --metrics

# Salvar a imagem com overlay anotado em arquivo
python cli_analyzer.py --image Gemini_Generated_Image_12iqg312iqg312iq.jpg --save-output resultado_Gemini_Generated_Image_12iqg312iqg312iq.jpg
```

---

## 🔬 Como Funciona o Algoritmo OpenCV

1. **Equalização e Limpeza**: Aplica um filtro de desfoque Gaussiano ($5 \times 5$) para atenuar ruídos de alta frequência do sensor óptico.
2. **Adaptive Thresholding**: O limiar adaptativo calcula o limiar de binarização localmente para cada bloco de pixels ($25 \times 25$), eliminando a influência de sombras de prédios e postes.
3. **Morfologia Matemática**: Uma dilatação morfológica conecta contornos de pára-brisas, pneus e lataria do veículo.
4. **Detecção de Bordas Canny**: Asfalto ou concreto vazios possuem densidade de bordas quase nula, enquanto veículos possuem alta concentração de bordas nítidas.
5. **Cálculo de Densidade e Dispersão**:
   - $\text{Taxa de Pixels} = \frac{\text{Pixels Ativos}}{\text{Área da Vaga}}$
   - $\text{Taxa de Bordas} = \frac{\text{Bordas Canny}}{\text{Área da Vaga}}$
   - $\text{Desvio Padrão} = \sigma(\text{Intensidade de Cinza})$
6. **Decisão de Ocupação**: Uma pontuação ponderada unificada compara os 3 índices contra o limiar calibrado para classificar a vaga como **LIVRE** ou **OCUPADA**.
