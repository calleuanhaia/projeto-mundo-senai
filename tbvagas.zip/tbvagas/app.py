"""
TBVAGAS: Servidor Web Flask & API REST de Monitoramento de Estacionamento
Desenvolvido com OpenCV e Arquitetura Modular
"""

import io
from pathlib import Path
from typing import Dict, Any
import cv2
from flask import Flask, render_template, request, jsonify, send_file, url_for
from werkzeug.utils import secure_filename

from config import OPENCV_DEFAULT_CONFIG, SERVER_HOST, SERVER_PORT, DEBUG_MODE
from core.detector import ParkingDetector, YOLO_AVAILABLE
from core.spot_manager import SpotManager
from core.image_manager import ImageManager

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32MB max upload

# Instanciar serviços principais
spot_manager = SpotManager()
image_manager = ImageManager()
detector = ParkingDetector()


@app.route("/")
def index():
    """Página principal da aplicação (Dashboard Executivo & Studio de Vagas)."""
    return render_template("index.html", yolo_available=YOLO_AVAILABLE)


@app.route("/api/system-status", methods=["GET"])
def system_status():
    """Retorna o status dos motores de visão computacional."""
    return jsonify({
        "status": "online",
        "opencv_version": cv2.__version__,
        "yolo_available": YOLO_AVAILABLE,
        "default_config": OPENCV_DEFAULT_CONFIG
    })


@app.route("/api/images", methods=["GET"])
def get_images():
    """Lista todas as imagens disponíveis com contagem de vagas."""
    images = image_manager.list_images()
    for img in images:
        filename = img["filename"]
        spots = spot_manager.get_spots(filename)
        img["spots_count"] = len(spots)
    return jsonify({"images": images})


@app.route("/api/images/upload", methods=["POST"])
def upload_image():
    """Recebe e processa upload de novas imagens de estacionamento."""
    if "image" not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado com a chave 'image'."}), 400

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "Nome de arquivo vazio."}), 400

    try:
        raw_bytes = file.read()
        saved_name = image_manager.save_image(file.filename, raw_bytes)
        return jsonify({
            "success": True,
            "filename": saved_name,
            "message": f"Imagem '{saved_name}' adicionada com sucesso!"
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/images/raw/<filename>", methods=["GET"])
def get_raw_image(filename: str):
    """Serve a imagem original do disco."""
    path = image_manager.get_image_path(filename)
    if not path:
        return jsonify({"error": "Imagem não encontrada"}), 404
    return send_file(str(path))


@app.route("/api/images/<filename>", methods=["DELETE"])
def delete_image(filename: str):
    """Exclui uma imagem do sistema."""
    success = image_manager.delete_image(filename)
    if success:
        return jsonify({"success": True, "message": f"Imagem '{filename}' removida."})
    return jsonify({"error": "Não foi possível remover o arquivo."}), 400


@app.route("/api/spots/<filename>", methods=["GET"])
def get_spots(filename: str):
    """Retorna os polígonos das vagas mapeadas para a imagem."""
    spots = spot_manager.get_spots(filename)
    return jsonify({
        "filename": filename,
        "total": len(spots),
        "spots": [s.to_dict() for s in spots]
    })


@app.route("/api/spots/<filename>", methods=["POST"])
def update_spots(filename: str):
    """Salva/atualiza a lista de vagas e polígonos de uma imagem."""
    data = request.get_json() or {}
    spots_data = data.get("spots", [])

    updated = spot_manager.set_spots(filename, spots_data)
    return jsonify({
        "success": True,
        "filename": filename,
        "saved_count": len(updated),
        "spots": [s.to_dict() for s in updated]
    })


@app.route("/api/analyze/<filename>", methods=["POST", "GET"])
def analyze_image(filename: str):
    """
    Executa a inferência OpenCV/IA na imagem solicitada e retorna JSON detalhado.
    """
    img = image_manager.read_image(filename)
    if img is None:
        return jsonify({"error": f"Imagem '{filename}' não encontrada"}), 404

    # Parâmetros de análise
    req_data = request.get_json() if request.method == "POST" else {}
    mode = req_data.get("mode") or request.args.get("mode", "hybrid")
    custom_thresh = req_data.get("threshold") or request.args.get("threshold", type=float)

    spots = spot_manager.get_spots(filename)
    if not spots:
        # Fallback para o primeiro conjunto de vagas
        spots = spot_manager.get_spots("")

    analysis = detector.analyze_spots(img, spots, mode=mode, custom_threshold=custom_thresh)
    analysis["filename"] = filename

    return jsonify(analysis)


@app.route("/api/annotated/<filename>", methods=["GET"])
def get_annotated_image(filename: str):
    """
    Retorna o stream de imagem processada em tempo real com overlay visual de vagas.
    """
    img = image_manager.read_image(filename)
    if img is None:
        return jsonify({"error": "Imagem não encontrada"}), 404

    mode = request.args.get("mode", "hybrid")
    threshold = request.args.get("threshold", default=None, type=float)
    show_metrics = request.args.get("metrics", "0") in ("1", "true", "True")

    spots = spot_manager.get_spots(filename)
    analysis = detector.analyze_spots(img, spots, mode=mode, custom_threshold=threshold)
    annotated = detector.annotate_image(img, analysis, show_metrics=show_metrics)

    # Codificar imagem em JPEG na memória
    success, buffer = cv2.imencode(".jpg", annotated, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    if not success:
        return jsonify({"error": "Erro ao codificar imagem"}), 500

    return send_file(
        io.BytesIO(buffer.tobytes()),
        mimetype="image/jpeg",
        as_attachment=False,
        download_name=f"analisado_{filename}"
    )


@app.route("/api/batch-analyze", methods=["GET"])
def batch_analyze():
    """Executa a análise de todas as imagens cadastradas para o relatório geral."""
    images = image_manager.list_images()
    results = []
    total_spots_all = 0
    total_occupied_all = 0

    mode = request.args.get("mode", "hybrid")

    for img_info in images:
        fn = img_info["filename"]
        img = image_manager.read_image(fn)
        if img is None:
            continue
        spots = spot_manager.get_spots(fn)
        res = detector.analyze_spots(img, spots, mode=mode)
        results.append({
            "filename": fn,
            "width": img_info["width"],
            "height": img_info["height"],
            "total_spots": res["total_spots"],
            "free_spots": res["free_spots"],
            "occupied_spots": res["occupied_spots"],
            "occupancy_rate": res["occupancy_rate"],
            "inference_time_ms": res["inference_time_ms"]
        })
        total_spots_all += res["total_spots"]
        total_occupied_all += res["occupied_spots"]

    total_free_all = total_spots_all - total_occupied_all
    global_rate = round((total_occupied_all / total_spots_all * 100.0), 1) if total_spots_all > 0 else 0.0

    return jsonify({
        "summary": {
            "total_images": len(images),
            "total_spots": total_spots_all,
            "free_spots": total_free_all,
            "occupied_spots": total_occupied_all,
            "global_occupancy_rate": global_rate
        },
        "details": results
    })


if __name__ == "__main__":
    print(f"[*] Iniciando Servidor TBVAGAS em http://{SERVER_HOST}:{SERVER_PORT}")
    app.run(host=SERVER_HOST, port=SERVER_PORT, debug=DEBUG_MODE)
