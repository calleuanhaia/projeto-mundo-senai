/**
 * TBVAGAS AI - Core Frontend Engine
 * Gerencia Canvas Interativo, Mapeamento Poligonal de Vagas,
 * Zoom/Pan em Tempo Real, Upload de Imagens e Chamadas à API OpenCV.
 */

class ParkingApp {
    constructor() {
        // Estado Geral
        this.activeAppMode = 'monitor'; // 'monitor' | 'editor'
        this.detectionEngine = 'hybrid'; // 'hybrid' | 'opencv' | 'yolo'
        this.threshold = 30.0;
        this.showMetricsOnBadges = false;
        this.showVehicles = true;

        // Modo Tempo Real & Simulação
        this.isLivePolling = true;
        this.liveIntervalId = null;
        this.isDemoCycling = false;
        this.demoIntervalId = null;

        // Rastreamento de Alterações em Tempo Real (Event Detection)
        this.previousSpotStates = new Map(); // spotId -> boolean (isOccupied)
        this.eventsHistory = [];
        this.recentlyChangedSpots = new Set();

        // Imagem Ativa
        this.currentFilename = null;
        this.imageElement = new Image();
        this.imageLoaded = false;
        this.imagesList = [];

        // Vagas e Análise
        this.spots = [];
        this.analysisResult = null;
        this.selectedSpotIndex = null;

        // Ferramentas do Editor
        this.editorTool = 'poly'; // 'poly' | 'box'
        this.drawingPoints = []; // Pontos do polígono em construção
        this.boxStartPoint = null;

        // Controle de Zoom & Pan
        this.scale = 1.0;
        this.panX = 0;
        this.panY = 0;
        this.isPanning = false;
        this.lastMousePos = { x: 0, y: 0 };
        this.draggingVertex = null; // { spotIndex, vertexIndex }

        // Elementos DOM
        this.canvas = document.getElementById('parking-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.viewportContainer = document.getElementById('viewport-container');

        this.initEventListeners();
        this.initApp();
    }

    async initApp() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        await this.loadImagesList();
        if (this.imagesList.length > 0) {
            // Iniciar com a imagem demarcada de referência
            const defaultImg = this.imagesList.find(img => img.filename.includes('12iqg')) || this.imagesList[0];
            await this.selectImage(defaultImg.filename);
        }
        this.startLivePolling();
    }

    getDisplayName(filename) {
        const found = this.imagesList.find(img => img.filename === filename);
        if (found && found.display_name) return found.display_name;
        if (filename.includes('12iqg')) return 'Noturno Demarcado (Vazio)';
        if (filename.includes('carros')) return 'Noturno com Carros (Ocupado)';
        if (filename.includes('dia')) return 'Câmera 04 (Diurno)';
        if (filename.includes('noturno')) return 'Noturno Original';
        return filename;
    }

    /* ==========================================================================
       CARREGAMENTO DE DADOS & API
       ========================================================================== */

    async loadImagesList() {
        try {
            const res = await fetch('/api/images');
            const data = await res.json();
            this.imagesList = data.images || [];
            this.renderGalleryList();
            document.getElementById('images-count-badge').textContent = this.imagesList.length;
        } catch (err) {
            this.showToast('Erro ao carregar lista de imagens', 'error');
        }
    }

    async selectImage(filename) {
        if (this.currentFilename === filename && this.imageLoaded) return;
        this.currentFilename = filename;
        this.showLoader(true);
        this.updateScenarioButtons(filename);

        const displayName = this.getDisplayName(filename);
        document.getElementById('current-image-name').textContent = displayName;

        // Carregar elemento Image
        return new Promise((resolve) => {
            this.imageElement = new Image();
            this.imageElement.crossOrigin = 'anonymous';
            this.imageElement.src = `/api/images/raw/${filename}?t=${Date.now()}`;
            this.imageElement.onload = async () => {
                this.imageLoaded = true;
                document.getElementById('current-image-res').textContent = 
                    `${this.imageElement.naturalWidth} x ${this.imageElement.naturalHeight}`;
                this.fitToScreen();
                await this.loadSpotsForCurrentImage();
                await this.triggerAnalysis(false);
                this.renderGalleryList();
                this.showLoader(false);
                resolve();
            };
            this.imageElement.onerror = () => {
                this.showToast('Erro ao abrir imagem', 'error');
                this.showLoader(false);
                resolve();
            };
        });
    }

    updateScenarioButtons(filename) {
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            const btnFile = btn.getAttribute('data-filename');
            if (btnFile === filename) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    toggleLiveMode() {
        this.isLivePolling = !this.isLivePolling;
        const btn = document.getElementById('btn-live-toggle');
        const label = document.getElementById('live-toggle-label');
        const pill = document.getElementById('live-indicator-pill');

        if (this.isLivePolling) {
            btn.classList.remove('paused');
            btn.classList.add('active');
            label.textContent = 'Tempo Real: ATIVO';
            if (pill) pill.style.display = 'inline-flex';
            this.showToast('Monitoramento em tempo real ativado', 'success');
            this.startLivePolling();
        } else {
            btn.classList.remove('active');
            btn.classList.add('paused');
            label.textContent = 'Tempo Real: PAUSADO';
            if (pill) pill.style.display = 'none';
            this.showToast('Monitoramento em tempo real pausado', 'info');
            this.stopLivePolling();
        }
    }

    startLivePolling() {
        if (this.liveIntervalId) clearInterval(this.liveIntervalId);
        this.liveIntervalId = setInterval(() => {
            if (this.activeAppMode === 'monitor' && !this.isDemoCycling && this.imageLoaded) {
                this.triggerAnalysis(false);
            }
        }, 4000);
    }

    stopLivePolling() {
        if (this.liveIntervalId) {
            clearInterval(this.liveIntervalId);
            this.liveIntervalId = null;
        }
    }

    toggleDemoCycle() {
        this.isDemoCycling = !this.isDemoCycling;
        const btn = document.getElementById('btn-demo-cycle');
        const label = document.getElementById('demo-cycle-label');

        if (this.isDemoCycling) {
            btn.classList.add('active');
            label.textContent = 'Parar Simulação';
            this.showToast('Simulação iniciada! Alternando fluxo de veículos a cada 5 segundos...', 'info');

            const cycleImages = [
                'Gemini_Generated_Image_12iqg312iqg312iq.jpg',
                'estacionamento_noturno_com_carros.jpg'
            ];
            let cycleIndex = this.currentFilename === cycleImages[0] ? 1 : 0;

            this.demoIntervalId = setInterval(async () => {
                const nextImg = cycleImages[cycleIndex];
                cycleIndex = (cycleIndex + 1) % cycleImages.length;
                
                const isCars = nextImg.includes('carros');
                this.showToast(
                    isCars ? '🚗 Veículos entraram e ocuparam as vagas!' : '✅ Veículos saíram! Vagas liberadas.',
                    isCars ? 'warning' : 'success'
                );
                await this.selectImage(nextImg);
            }, 5000);
        } else {
            btn.classList.remove('active');
            label.textContent = 'Simular Fluxo';
            if (this.demoIntervalId) {
                clearInterval(this.demoIntervalId);
                this.demoIntervalId = null;
            }
            this.showToast('Simulação pausada', 'info');
        }
    }

    async loadSpotsForCurrentImage() {
        try {
            const res = await fetch(`/api/spots/${this.currentFilename}`);
            const data = await res.json();
            this.spots = data.spots || [];
            this.drawingPoints = [];
            this.selectedSpotIndex = null;
            this.renderSpotsList();
        } catch (err) {
            console.error('Erro ao buscar vagas:', err);
            this.spots = [];
        }
    }

    async triggerAnalysis(showLargeLoader = true) {
        if (!this.currentFilename) return;
        if (showLargeLoader) this.showLoader(true);
        try {
            const res = await fetch(`/api/analyze/${this.currentFilename}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    mode: this.detectionEngine,
                    threshold: this.threshold
                })
            });
            const data = await res.json();
            this.analysisResult = data;
            this.detectStateChanges(data);
            this.updateMetricsUI(data);
            this.renderSpotsList();
            this.redraw();
        } catch (err) {
            this.showToast('Falha na inferência OpenCV', 'error');
        } finally {
            if (showLargeLoader) this.showLoader(false);
        }
    }

    detectStateChanges(newAnalysis) {
        if (!newAnalysis || !newAnalysis.spots) return;
        const currentSpots = newAnalysis.spots;
        let changesDetected = 0;

        currentSpots.forEach(s => {
            const spotId = s.spot_id;
            const isOcc = s.is_occupied;
            const spotLabel = s.label || spotId;

            if (this.previousSpotStates.has(spotId)) {
                const prevOcc = this.previousSpotStates.get(spotId);
                if (prevOcc !== isOcc) {
                    changesDetected++;
                    const now = new Date();
                    const timeStr = now.toLocaleTimeString('pt-BR');

                    if (isOcc) {
                        // Novo carro estacionado!
                        const eventObj = {
                            type: 'entry',
                            spotId: spotId,
                            label: spotLabel,
                            time: timeStr,
                            text: `Novo carro estacionado em ${spotLabel}`
                        };
                        this.eventsHistory.unshift(eventObj);
                        this.showToast(`🚗 NOVO CARRO ESTACIONADO na ${spotLabel}!`, 'warning');
                        this.updateChangeBanner(eventObj);
                    } else {
                        // Vaga liberada!
                        const eventObj = {
                            type: 'exit',
                            spotId: spotId,
                            label: spotLabel,
                            time: timeStr,
                            text: `Vaga liberada: ${spotLabel}`
                        };
                        this.eventsHistory.unshift(eventObj);
                        this.showToast(`✅ Vaga ${spotLabel} liberada!`, 'success');
                        this.updateChangeBanner(eventObj);
                    }

                    // Destacar a vaga alterada no canvas por 8 segundos
                    this.recentlyChangedSpots.add(spotId);
                    setTimeout(() => {
                        this.recentlyChangedSpots.delete(spotId);
                        this.redraw();
                    }, 8000);
                }
            }
            this.previousSpotStates.set(spotId, isOcc);
        });

        if (this.eventsHistory.length > 25) {
            this.eventsHistory = this.eventsHistory.slice(0, 25);
        }
        this.renderEventsLog();
    }

    updateChangeBanner(eventObj) {
        const banner = document.getElementById('latest-change-banner');
        const textElem = document.getElementById('latest-change-text');
        if (!banner || !textElem) return;

        banner.className = `latest-change-banner ${eventObj.type === 'entry' ? 'highlight-entry' : 'highlight-exit'}`;
        textElem.innerHTML = `<strong>${eventObj.type === 'entry' ? '🚨 NOVO CARRO:' : '✅ LIBERADA:'}</strong> ${eventObj.label} (${eventObj.time})`;
    }

    renderEventsLog() {
        const container = document.getElementById('events-log-container');
        if (!container) return;

        if (this.eventsHistory.length === 0) {
            container.innerHTML = '<div class="empty-events-state">Nenhuma alteração registrada ainda.</div>';
            return;
        }

        container.innerHTML = '';
        this.eventsHistory.forEach(ev => {
            const item = document.createElement('div');
            item.className = `event-item ${ev.type}`;
            item.innerHTML = `
                <div class="event-item-left">
                    <span class="event-type-tag ${ev.type}">${ev.type === 'entry' ? 'ENTRADA' : 'SAÍDA'}</span>
                    <strong>${ev.label}</strong>
                </div>
                <span class="event-time">${ev.time}</span>
            `;
            container.appendChild(item);
        });
    }

    async saveSpots() {
        if (!this.currentFilename) return;
        try {
            const res = await fetch(`/api/spots/${this.currentFilename}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ spots: this.spots })
            });
            const data = await res.json();
            if (data.success) {
                this.showToast(`${data.saved_count} vagas salvas com sucesso!`, 'success');
                await this.triggerAnalysis();
            }
        } catch (err) {
            this.showToast('Erro ao salvar vagas', 'error');
        }
    }

    async uploadFiles(files) {
        if (!files || files.length === 0) return;
        this.showLoader(true);
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const formData = new FormData();
            formData.append('image', file);

            try {
                const res = await fetch('/api/images/upload', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    this.showToast(`Upload concluído: ${data.filename}`, 'success');
                    await this.loadImagesList();
                    await this.selectImage(data.filename);
                } else {
                    this.showToast(data.error || 'Erro no upload', 'error');
                }
            } catch (err) {
                this.showToast('Erro na conexão com o servidor', 'error');
            }
        }
        this.showLoader(false);
    }

    /* ==========================================================================
       CANVAS & RENDERING ENGINE
       ========================================================================== */

    resizeCanvas() {
        const rect = this.viewportContainer.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        this.redraw();
    }

    fitToScreen() {
        if (!this.imageLoaded) return;
        const cw = this.canvas.width;
        const ch = this.canvas.height;
        const iw = this.imageElement.naturalWidth;
        const ih = this.imageElement.naturalHeight;

        const scaleX = (cw - 40) / iw;
        const scaleY = (ch - 40) / ih;
        this.scale = Math.min(scaleX, scaleY, 1.0);

        this.panX = (cw - iw * this.scale) / 2;
        this.panY = (ch - ih * this.scale) / 2;
        this.redraw();
    }

    // Conversão de coordenadas tela <-> imagem
    screenToImage(sx, sy) {
        const ix = (sx - this.panX) / this.scale;
        const iy = (sy - this.panY) / this.scale;
        return { x: Math.round(ix), y: Math.round(iy) };
    }

    imageToScreen(ix, iy) {
        const sx = ix * this.scale + this.panX;
        const sy = iy * this.scale + this.panY;
        return { x: sx, y: sy };
    }

    redraw() {
        if (!this.ctx) return;
        const { width, height } = this.canvas;
        this.ctx.clearRect(0, 0, width, height);

        if (!this.imageLoaded) return;

        this.ctx.save();
        this.ctx.translate(this.panX, this.panY);
        this.ctx.scale(this.scale, this.scale);

        // 1. Desenhar imagem de fundo
        this.ctx.drawImage(this.imageElement, 0, 0);

        // 2. Desenhar vagas mapeadas
        this.spots.forEach((spot, index) => {
            const isSelected = this.selectedSpotIndex === index;
            const analysis = this.getSpotAnalysis(spot.id);
            const isOccupied = analysis ? analysis.is_occupied : false;

            this.drawSpotPolygon(spot, isOccupied, isSelected, analysis);
        });

        // 3. Desenhar caixas dos veículos detectados pela IA (YOLO)
        if (this.showVehicles && this.activeAppMode === 'monitor') {
            this.drawVehicleDetections();
        }

        // 4. Desenhar pontos em progresso de desenho (Modo Editor)
        if (this.activeAppMode === 'editor' && this.drawingPoints.length > 0) {
            this.drawActiveDrawingPolygon();
        }

        this.ctx.restore();
    }

    drawVehicleDetections() {
        if (!this.analysisResult || !this.analysisResult.yolo_detections) return;
        const detections = this.analysisResult.yolo_detections;
        if (detections.length === 0) return;

        this.ctx.save();
        detections.forEach((det) => {
            const [x1, y1, x2, y2] = det.box;
            const w = x2 - x1;
            const h = y2 - y1;

            // Preenchimento ciano translúcido
            this.ctx.fillStyle = 'rgba(6, 182, 212, 0.12)';
            this.ctx.fillRect(x1, y1, w, h);

            // Borda neon tracejada
            this.ctx.lineWidth = 2 / this.scale;
            this.ctx.strokeStyle = '#06b6d4';
            this.ctx.setLineDash([6 / this.scale, 4 / this.scale]);
            this.ctx.strokeRect(x1, y1, w, h);
            this.ctx.setLineDash([]);

            // Badge superior com classe e confiança
            const vehicleLabel = `🚗 ${det.class.toUpperCase()} (${Math.round(det.confidence * 100)}%)`;
            const fontSize = Math.max(10, Math.round(11 / this.scale));
            this.ctx.font = `700 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
            const metrics = this.ctx.measureText(vehicleLabel);
            const padX = 6 / this.scale;
            const padY = 3 / this.scale;
            const badgeW = metrics.width + padX * 2;
            const badgeH = fontSize + padY * 2;

            const bx = x1;
            const by = Math.max(0, y1 - badgeH - 3 / this.scale);

            this.ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
            this.ctx.beginPath();
            this.ctx.roundRect(bx, by, badgeW, badgeH, 3 / this.scale);
            this.ctx.fill();

            this.ctx.strokeStyle = '#06b6d4';
            this.ctx.lineWidth = 1 / this.scale;
            this.ctx.stroke();

            this.ctx.fillStyle = '#38bdf8';
            this.ctx.textAlign = 'left';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(vehicleLabel, bx + padX, by + badgeH / 2);
        });
        this.ctx.restore();
    }

    getSpotAnalysis(spotId) {
        if (!this.analysisResult || !this.analysisResult.spots) return null;
        return this.analysisResult.spots.find(s => s.spot_id === spotId);
    }

    drawSpotPolygon(spot, isOccupied, isSelected, analysis) {
        const pts = spot.points;
        if (!pts || pts.length < 3) return;

        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) {
            this.ctx.lineTo(pts[i][0], pts[i][1]);
        }
        this.ctx.closePath();

        // Cores
        let fillColor = isOccupied ? 'rgba(239, 68, 68, 0.35)' : 'rgba(16, 185, 129, 0.35)';
        let strokeColor = isOccupied ? '#ef4444' : '#10b981';

        const isChanged = this.recentlyChangedSpots && this.recentlyChangedSpots.has(spot.id);

        if (isSelected) {
            fillColor = 'rgba(99, 102, 241, 0.45)';
            strokeColor = '#a5b4fc';
        }

        if (isChanged) {
            fillColor = isOccupied ? 'rgba(244, 63, 94, 0.55)' : 'rgba(16, 185, 129, 0.55)';
            strokeColor = isOccupied ? '#f43f5e' : '#10b981';
        }

        this.ctx.fillStyle = fillColor;
        this.ctx.fill();

        this.ctx.lineWidth = isChanged ? 3.5 / this.scale : (isSelected ? 3 / this.scale : 2 / this.scale);
        this.ctx.strokeStyle = strokeColor;
        this.ctx.stroke();

        // Em modo editor: desenhar alças / vértices para arrastar
        if (this.activeAppMode === 'editor') {
            const handleRadius = Math.max(4, 5 / this.scale);
            pts.forEach((pt, vi) => {
                this.ctx.beginPath();
                this.ctx.arc(pt[0], pt[1], handleRadius, 0, Math.PI * 2);
                this.ctx.fillStyle = isSelected ? '#ffffff' : strokeColor;
                this.ctx.fill();
                this.ctx.lineWidth = 1.5 / this.scale;
                this.ctx.strokeStyle = '#000000';
                this.ctx.stroke();
            });
        }

        // Desenhar Badge / Etiqueta no Centroide
        const center = this.calculatePolygonCenter(pts);
        this.drawSpotBadge(center.x, center.y, spot, isOccupied, analysis, isSelected);

        this.ctx.restore();
    }

    calculatePolygonCenter(pts) {
        let x = 0, y = 0;
        pts.forEach(p => { x += p[0]; y += p[1]; });
        return { x: x / pts.length, y: y / pts.length };
    }

    drawSpotBadge(cx, cy, spot, isOccupied, analysis, isSelected) {
        const textLabel = spot.label || spot.id;
        let badgeText = textLabel;

        if (this.activeAppMode === 'monitor') {
            const isChanged = this.recentlyChangedSpots && this.recentlyChangedSpots.has(spot.id);
            if (isChanged) {
                badgeText = `${isOccupied ? '🚨 NOVO CARRO: ' : '🟢 LIBERADA: '}${textLabel}`;
            } else {
                badgeText += `: ${isOccupied ? 'OCUPADA' : 'LIVRE'}`;
                if (this.showMetricsOnBadges && analysis) {
                    badgeText += ` (${analysis.score})`;
                }
            }
        }

        const fontSize = Math.max(10, Math.round(12 / this.scale));
        this.ctx.font = `600 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
        const textMetrics = this.ctx.measureText(badgeText);
        const paddingX = 6 / this.scale;
        const paddingY = 4 / this.scale;
        const boxW = textMetrics.width + paddingX * 2;
        const boxH = fontSize + paddingY * 2;

        const bx = cx - boxW / 2;
        const by = cy - boxH / 2;

        // Fundo do badge
        this.ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        this.ctx.beginPath();
        this.ctx.roundRect(bx, by, boxW, boxH, 4 / this.scale);
        this.ctx.fill();

        // Borda do badge
        this.ctx.lineWidth = 1 / this.scale;
        this.ctx.strokeStyle = isOccupied ? '#ef4444' : '#10b981';
        if (isSelected) this.ctx.strokeStyle = '#818cf8';
        this.ctx.stroke();

        // Texto
        this.ctx.fillStyle = '#ffffff';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(badgeText, cx, cy);
    }

    drawActiveDrawingPolygon() {
        if (this.drawingPoints.length === 0) return;

        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(this.drawingPoints[0][0], this.drawingPoints[0][1]);
        for (let i = 1; i < this.drawingPoints.length; i++) {
            this.ctx.lineTo(this.drawingPoints[i][0], this.drawingPoints[i][1]);
        }

        this.ctx.lineWidth = 2 / this.scale;
        this.ctx.strokeStyle = '#38bdf8';
        this.ctx.setLineDash([4 / this.scale, 4 / this.scale]);
        this.ctx.stroke();
        this.ctx.setLineDash([]);

        // Desenhar círculos nos pontos marcados
        this.drawingPoints.forEach((pt, idx) => {
            this.ctx.beginPath();
            this.ctx.arc(pt[0], pt[1], 5 / this.scale, 0, Math.PI * 2);
            this.ctx.fillStyle = '#38bdf8';
            this.ctx.fill();
            this.ctx.strokeStyle = '#ffffff';
            this.ctx.lineWidth = 1.5 / this.scale;
            this.ctx.stroke();

            // Número do ponto
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = `bold ${Math.max(10, 11 / this.scale)}px sans-serif`;
            this.ctx.fillText((idx + 1).toString(), pt[0] + 8 / this.scale, pt[1] - 8 / this.scale);
        });

        this.ctx.restore();
    }

    /* ==========================================================================
       INTERAÇÃO COM O MOUSE (CANVAS)
       ========================================================================== */

    initEventListeners() {
        // Alternância de Modos (Monitoramento x Mapeamento)
        document.getElementById('btn-mode-monitor').addEventListener('click', () => this.switchMode('monitor'));
        document.getElementById('btn-mode-editor').addEventListener('click', () => this.switchMode('editor'));

        // Ferramentas de Editor
        document.getElementById('tool-poly').addEventListener('click', () => {
            this.editorTool = 'poly';
            this.updateToolButtons('tool-poly');
        });
        document.getElementById('tool-box').addEventListener('click', () => {
            this.editorTool = 'box';
            this.updateToolButtons('tool-box');
        });
        document.getElementById('tool-undo').addEventListener('click', () => this.undoLastPoint());
        document.getElementById('btn-save-spots').addEventListener('click', () => this.saveSpots());

        // Zoom & Ferramentas Rápidas
        document.getElementById('btn-zoom-in').addEventListener('click', () => this.zoom(1.2));
        document.getElementById('btn-zoom-out').addEventListener('click', () => this.zoom(0.8));
        document.getElementById('btn-zoom-fit').addEventListener('click', () => this.fitToScreen());
        document.getElementById('btn-refresh-analysis').addEventListener('click', () => this.triggerAnalysis());
        document.getElementById('btn-download-annotated').addEventListener('click', () => this.downloadAnnotatedImage());

        // Configurações do Motor
        document.getElementById('select-detection-mode').addEventListener('change', (e) => {
            this.detectionEngine = e.target.value;
            document.getElementById('val-active-mode').textContent = this.detectionEngine.toUpperCase();
            this.triggerAnalysis();
        });

        const slider = document.getElementById('slider-threshold');
        slider.addEventListener('input', (e) => {
            this.threshold = parseFloat(e.target.value);
            document.getElementById('val-slider-threshold').textContent = this.threshold.toFixed(1);
        });
        slider.addEventListener('change', () => this.triggerAnalysis());

        document.getElementById('chk-show-metrics').addEventListener('change', (e) => {
            this.showMetricsOnBadges = e.target.checked;
            this.redraw();
        });

        // Upload de Imagens
        const fileInput = document.getElementById('file-upload-input');
        fileInput.addEventListener('change', (e) => this.uploadFiles(e.target.files));

        // Botões de Cenários Rápidos (Alternância Instantânea)
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetBtn = e.currentTarget;
                const filename = targetBtn.getAttribute('data-filename');
                if (filename) {
                    this.selectImage(filename);
                }
            });
        });

        // Alternadores de Tempo Real & Simulação
        const liveToggle = document.getElementById('btn-live-toggle');
        if (liveToggle) liveToggle.addEventListener('click', () => this.toggleLiveMode());

        const demoCycle = document.getElementById('btn-demo-cycle');
        if (demoCycle) demoCycle.addEventListener('click', () => this.toggleDemoCycle());

        const chkVehicles = document.getElementById('chk-show-vehicles');
        if (chkVehicles) {
            chkVehicles.addEventListener('change', (e) => {
                this.showVehicles = e.target.checked;
                this.redraw();
            });
        }

        const dropzone = document.getElementById('image-dropzone');
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            this.uploadFiles(e.dataTransfer.files);
        });
        dropzone.addEventListener('click', () => fileInput.click());

        // Exportar Relatório
        document.getElementById('btn-export-report').addEventListener('click', () => this.exportJsonReport());

        // Modal de Vagas
        document.getElementById('modal-close-btn').addEventListener('click', () => this.closeSpotModal());
        document.getElementById('modal-save-spot-btn').addEventListener('click', () => this.saveModalSpotProps());
        document.getElementById('modal-delete-spot-btn').addEventListener('click', () => this.deleteModalSpot());

        // Mouse Events no Canvas
        this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e));
        this.canvas.addEventListener('wheel', (e) => this.handleWheel(e), { passive: false });
        this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    }

    switchMode(mode) {
        this.activeAppMode = mode;
        document.getElementById('btn-mode-monitor').classList.toggle('active', mode === 'monitor');
        document.getElementById('btn-mode-editor').classList.toggle('active', mode === 'editor');

        const editorGroup = document.getElementById('editor-tools-group');
        const editorHint = document.getElementById('editor-hint');

        if (mode === 'editor') {
            editorGroup.style.display = 'flex';
            editorHint.style.display = 'flex';
            this.viewportContainer.classList.add('drawing');
            this.showToast('Modo de Mapeamento ativado. Clique 4 pontos para demarcar cada vaga.', 'info');
        } else {
            editorGroup.style.display = 'none';
            editorHint.style.display = 'none';
            this.viewportContainer.classList.remove('drawing');
            this.drawingPoints = [];
            this.selectedSpotIndex = null;
        }
        this.redraw();
    }

    updateToolButtons(activeId) {
        document.getElementById('tool-poly').classList.toggle('active', activeId === 'tool-poly');
        document.getElementById('tool-box').classList.toggle('active', activeId === 'tool-box');
    }

    handleMouseDown(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const imgPt = this.screenToImage(mx, my);

        // Se botão do meio ou segurando Alt/Espaço -> Pan
        if (e.button === 1 || e.altKey || e.shiftKey) {
            this.isPanning = true;
            this.lastMousePos = { x: mx, y: my };
            this.viewportContainer.classList.add('panning');
            return;
        }

        // Modo Editor: verificar se clicou em uma alça/vértice para arrastar
        if (this.activeAppMode === 'editor' && e.button === 0) {
            const hitHandle = this.findHandleNear(imgPt.x, imgPt.y);
            if (hitHandle) {
                this.draggingVertex = hitHandle;
                this.selectedSpotIndex = hitHandle.spotIndex;
                this.renderSpotsList();
                this.redraw();
                return;
            }

            // Se ferramenta de polígono: adicionar ponto
            if (this.editorTool === 'poly') {
                this.drawingPoints.push([imgPt.x, imgPt.y]);
                if (this.drawingPoints.length === 4) {
                    this.finishPolygonSpot();
                } else {
                    this.redraw();
                }
                return;
            }

            // Se ferramenta retângulo
            if (this.editorTool === 'box') {
                if (!this.boxStartPoint) {
                    this.boxStartPoint = [imgPt.x, imgPt.y];
                    this.drawingPoints = [[imgPt.x, imgPt.y]];
                    this.redraw();
                } else {
                    const [x1, y1] = this.boxStartPoint;
                    const x2 = imgPt.x, y2 = imgPt.y;
                    this.spots.push({
                        id: `VAGA-${this.spots.length + 1 < 10 ? '0' : ''}${this.spots.length + 1}`,
                        label: `Vaga ${this.spots.length + 1}`,
                        type: 'Normal',
                        points: [[x1, y1], [x2, y1], [x2, y2], [x1, y2]],
                        image_name: this.currentFilename
                    });
                    this.boxStartPoint = null;
                    this.drawingPoints = [];
                    this.renderSpotsList();
                    this.saveSpots();
                    this.redraw();
                }
                return;
            }
        }

        // Seleção de vaga clicando dentro do polígono
        const clickedSpotIdx = this.findSpotAt(imgPt.x, imgPt.y);
        if (clickedSpotIdx !== null) {
            this.selectedSpotIndex = clickedSpotIdx;
            this.renderSpotsList();
            this.redraw();

            // Duplo clique ou clique simples no editor abre modal de edição
            if (e.detail >= 2 || this.activeAppMode === 'editor') {
                this.openSpotModal(this.spots[clickedSpotIdx]);
            }
        } else {
            // Iniciar Pan simples se não clicou em nada
            this.isPanning = true;
            this.lastMousePos = { x: mx, y: my };
            this.viewportContainer.classList.add('panning');
        }
    }

    handleMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;

        if (this.isPanning) {
            const dx = mx - this.lastMousePos.x;
            const dy = my - this.lastMousePos.y;
            this.panX += dx;
            this.panY += dy;
            this.lastMousePos = { x: mx, y: my };
            this.redraw();
            return;
        }

        if (this.draggingVertex) {
            const imgPt = this.screenToImage(mx, my);
            const { spotIndex, vertexIndex } = this.draggingVertex;
            this.spots[spotIndex].points[vertexIndex] = [imgPt.x, imgPt.y];
            this.redraw();
            return;
        }
    }

    handleMouseUp() {
        if (this.isPanning) {
            this.isPanning = false;
            this.viewportContainer.classList.remove('panning');
        }
        if (this.draggingVertex) {
            this.draggingVertex = null;
            this.saveSpots(); // Auto-save ao mover ponto
        }
    }

    handleWheel(e) {
        e.preventDefault();
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;

        const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
        this.zoomAtPoint(zoomFactor, mx, my);
    }

    zoom(factor) {
        const cx = this.canvas.width / 2;
        const cy = this.canvas.height / 2;
        this.zoomAtPoint(factor, cx, cy);
    }

    zoomAtPoint(factor, cx, cy) {
        const newScale = Math.max(0.1, Math.min(this.scale * factor, 8.0));
        this.panX = cx - (cx - this.panX) * (newScale / this.scale);
        this.panY = cy - (cy - this.panY) * (newScale / this.scale);
        this.scale = newScale;
        this.redraw();
    }

    undoLastPoint() {
        if (this.drawingPoints.length > 0) {
            this.drawingPoints.pop();
            this.redraw();
        } else if (this.spots.length > 0) {
            const removed = this.spots.pop();
            this.renderSpotsList();
            this.saveSpots();
            this.redraw();
            this.showToast(`Vaga '${removed.label}' removida`, 'info');
        }
    }

    finishPolygonSpot() {
        const newSpotNumber = this.spots.length + 1;
        const newSpotId = `VAGA-${newSpotNumber < 10 ? '0' : ''}${newSpotNumber}`;
        const newSpot = {
            id: newSpotId,
            label: `Vaga ${newSpotNumber}`,
            type: 'Normal',
            points: [...this.drawingPoints],
            image_name: this.currentFilename
        };

        this.spots.push(newSpot);
        this.drawingPoints = [];
        this.selectedSpotIndex = this.spots.length - 1;
        this.renderSpotsList();
        this.saveSpots();
        this.redraw();
        this.showToast(`Vaga '${newSpot.label}' mapeada!`, 'success');
    }

    findHandleNear(ix, iy) {
        const threshold = 12 / this.scale;
        for (let si = 0; si < this.spots.length; si++) {
            const pts = this.spots[si].points;
            for (let vi = 0; vi < pts.length; vi++) {
                const dist = Math.hypot(pts[vi][0] - ix, pts[vi][1] - iy);
                if (dist <= threshold) {
                    return { spotIndex: si, vertexIndex: vi };
                }
            }
        }
        return null;
    }

    findSpotAt(ix, iy) {
        for (let i = this.spots.length - 1; i >= 0; i--) {
            if (this.isPointInsidePolygon([ix, iy], this.spots[i].points)) {
                return i;
            }
        }
        return null;
    }

    isPointInsidePolygon(point, vs) {
        const x = point[0], y = point[1];
        let inside = false;
        for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
            const xi = vs[i][0], yi = vs[i][1];
            const xj = vs[j][0], yj = vs[j][1];
            const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
            if (intersect) inside = !inside;
        }
        return inside;
    }

    /* ==========================================================================
       UI UPDATES & SIDEBAR LISTS
       ========================================================================== */

    updateMetricsUI(data) {
        if (!data) return;
        document.getElementById('stat-total-spots').textContent = data.total_spots;
        document.getElementById('stat-free-spots').textContent = data.free_spots;
        document.getElementById('stat-occupied-spots').textContent = data.occupied_spots;
        document.getElementById('stat-occupancy-rate').textContent = `${data.occupancy_rate}%`;
        document.getElementById('occupancy-progress-bar').style.width = `${data.occupancy_rate}%`;
        document.getElementById('val-inference-time').textContent = `${data.inference_time_ms} ms`;
        document.getElementById('spots-count-badge').textContent = data.total_spots;
    }

    renderSpotsList() {
        const container = document.getElementById('spots-items-container');
        container.innerHTML = '';

        if (this.spots.length === 0) {
            container.innerHTML = '<div class="empty-state">Nenhuma vaga cadastrada nesta imagem.</div>';
            return;
        }

        this.spots.forEach((spot, idx) => {
            const analysis = this.getSpotAnalysis(spot.id);
            const isOccupied = analysis ? analysis.is_occupied : false;
            const scoreText = analysis ? `Score: ${analysis.score}` : '';

            const row = document.createElement('div');
            row.className = `spot-row-item ${this.selectedSpotIndex === idx ? 'active' : ''}`;
            row.innerHTML = `
                <div class="spot-row-left">
                    <span class="spot-status-badge ${isOccupied ? 'badge-occupied' : 'badge-free'}">
                        ${isOccupied ? 'Ocupada' : 'Livre'}
                    </span>
                    <div>
                        <div class="spot-name-text">${spot.label || spot.id}</div>
                        <div class="spot-category-tag">${spot.type || 'Normal'}</div>
                    </div>
                </div>
                <div class="spot-row-actions">
                    <span class="spot-score-label">${scoreText}</span>
                    <button class="btn-xs btn-outline" title="Editar">⚙</button>
                </div>
            `;

            row.addEventListener('click', (e) => {
                this.selectedSpotIndex = idx;
                this.renderSpotsList();
                this.redraw();
                if (e.target.tagName === 'BUTTON') {
                    this.openSpotModal(spot);
                }
            });

            container.appendChild(row);
        });
    }

    renderGalleryList() {
        const container = document.getElementById('gallery-items-container');
        container.innerHTML = '';

        this.imagesList.forEach(img => {
            const card = document.createElement('div');
            card.className = `gallery-item-card ${this.currentFilename === img.filename ? 'active' : ''}`;
            card.innerHTML = `
                <div class="gallery-thumb-wrapper">
                    <img src="/api/images/raw/${img.filename}" alt="${img.filename}" loading="lazy">
                </div>
                <div class="gallery-info">
                    <div class="gallery-filename" title="${img.display_name || img.filename}">${img.display_name || img.filename}</div>
                    <div class="gallery-meta">${img.width}x${img.height} • ${img.spots_count || 0} vagas</div>
                </div>
            `;
            card.addEventListener('click', () => this.selectImage(img.filename));
            container.appendChild(card);
        });
    }

    /* ==========================================================================
       MODAL DE EDIÇÃO DE PROPRIEDADES DA VAGA
       ========================================================================== */

    openSpotModal(spot) {
        if (!spot) return;
        document.getElementById('input-spot-label').value = spot.label || spot.id;
        document.getElementById('select-spot-type').value = spot.type || 'Normal';
        document.getElementById('modal-spot-title').textContent = `Editar ${spot.label || spot.id}`;
        document.getElementById('spot-modal').style.display = 'flex';
    }

    closeSpotModal() {
        document.getElementById('spot-modal').style.display = 'none';
    }

    saveModalSpotProps() {
        if (this.selectedSpotIndex === null || !this.spots[this.selectedSpotIndex]) return;
        const spot = this.spots[this.selectedSpotIndex];
        spot.label = document.getElementById('input-spot-label').value.trim() || spot.id;
        spot.type = document.getElementById('select-spot-type').value;

        this.closeSpotModal();
        this.renderSpotsList();
        this.saveSpots();
        this.redraw();
        this.showToast('Vaga atualizada!', 'success');
    }

    deleteModalSpot() {
        if (this.selectedSpotIndex === null) return;
        const removed = this.spots.splice(this.selectedSpotIndex, 1);
        this.selectedSpotIndex = null;
        this.closeSpotModal();
        this.renderSpotsList();
        this.saveSpots();
        this.redraw();
        this.showToast(`Vaga '${removed[0]?.label}' removida`, 'info');
    }

    /* ==========================================================================
       UTILITÁRIOS: TOAST, LOADER, EXPORT
       ========================================================================== */

    showLoader(show) {
        document.getElementById('viewport-loader').style.display = show ? 'flex' : 'none';
    }

    showToast(msg, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = msg;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 3500);
    }

    downloadAnnotatedImage() {
        if (!this.currentFilename) return;
        const url = `/api/annotated/${this.currentFilename}?mode=${this.detectionEngine}&threshold=${this.threshold}&metrics=${this.showMetricsOnBadges ? 1 : 0}`;
        const a = document.createElement('a');
        a.href = url;
        a.download = `tbvagas_analisado_${this.currentFilename}`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        this.showToast('Download da imagem OpenCV iniciado!', 'success');
    }

    exportJsonReport() {
        if (!this.analysisResult) {
            this.showToast('Execute a análise antes de exportar', 'error');
            return;
        }
        const report = {
            metadata: {
                timestamp: new Date().toISOString(),
                filename: this.currentFilename,
                engine: this.detectionEngine,
                threshold: this.threshold
            },
            summary: {
                total_spots: this.analysisResult.total_spots,
                free_spots: this.analysisResult.free_spots,
                occupied_spots: this.analysisResult.occupied_spots,
                occupancy_rate: this.analysisResult.occupancy_rate,
                inference_time_ms: this.analysisResult.inference_time_ms
            },
            spots: this.analysisResult.spots
        };

        const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `relatorio_estacionamento_${this.currentFilename.split('.')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        this.showToast('Relatório JSON exportado!', 'success');
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ParkingApp();
});
