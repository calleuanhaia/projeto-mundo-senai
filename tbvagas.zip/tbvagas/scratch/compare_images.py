import cv2
import numpy as np

# Let's inspect the colors and regions of Gemini_Generated_Image_12iqg312iqg312iq.jpg and estacionamento_noturno.jpg
img_gemini = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')
img_noturno = cv2.imread('data/images/estacionamento_noturno.jpg')
img_dia = cv2.imread('data/images/estacionamento_dia_cam04.jpg')

print("Gemini shape:", img_gemini.shape if img_gemini is not None else None)
print("Noturno shape:", img_noturno.shape if img_noturno is not None else None)
print("Dia shape:", img_dia.shape if img_dia is not None else None)

# Compare pixel difference between img_gemini and img_noturno
if img_gemini is not None and img_noturno is not None:
    diff = cv2.absdiff(img_gemini, img_noturno)
    print("Mean diff between gemini and noturno:", diff.mean())

