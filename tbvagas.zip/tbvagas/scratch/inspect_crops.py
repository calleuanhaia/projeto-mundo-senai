import cv2
import numpy as np

img = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')
orig_8_spots_data = [
  {"id": "PCD-01", "label": "PCD 01", "type": "PCD", "points": [[115, 780], [305, 780], [330, 715], [150, 715]]},
  {"id": "VAGA-02", "label": "Vaga 02", "type": "Normal", "points": [[150, 715], [330, 715], [350, 670], [178, 670]]},
  {"id": "VAGA-03", "label": "Vaga 03", "type": "Normal", "points": [[178, 670], [350, 670], [365, 635], [198, 635]]},
  {"id": "VAGA-04", "label": "Vaga 04", "type": "Normal", "points": [[198, 635], [365, 635], [378, 608], [215, 608]]},
  {"id": "VAGA-08", "label": "Vaga 08", "type": "Normal", "points": [[805, 635], [1025, 635], [1018, 670], [795, 670]]},
  {"id": "VAGA-07", "label": "Vaga 07", "type": "Normal", "points": [[795, 670], [1018, 670], [1010, 715], [780, 715]]},
  {"id": "VAGA-05", "label": "Vaga 05", "type": "Normal", "points": [[780, 715], [1010, 715], [1000, 770], [765, 770]]},
  {"id": "VAGA-06", "label": "Vaga 06", "type": "Normal", "points": [[765, 770], [1000, 770], [990, 830], [750, 830]]}
]

for s in orig_8_spots_data:
    pts = np.array(s['points'], np.int32)
    x, y, w, h = cv2.boundingRect(pts)
    crop = img[y:y+h, x:x+w]
    cv2.imwrite(f"scratch/crop_{s['id']}.jpg", crop)
print("Saved crops")

