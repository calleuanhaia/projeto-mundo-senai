import json

with open('C:/Users/calleu_anhaia/.gemini/antigravity/brain/33e99043-f85e-41f9-8cac-a176287c0fba/.system_generated/logs/transcript_full.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for s in range(180, 190):
    if s < len(lines):
        d = json.loads(lines[s])
        print(f"=== STEP {s} ({d.get('type')}) ===")
        if d.get('thinking'):
            print("THINKING:", d.get('thinking')[:400])
        if d.get('tool_calls'):
            print("TOOL CALL:", d.get('tool_calls'))
        if d.get('content'):
            print("CONTENT:", str(d.get('content'))[:400])

