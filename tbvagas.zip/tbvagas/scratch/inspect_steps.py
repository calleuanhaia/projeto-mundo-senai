import json

with open('C:/Users/calleu_anhaia/.gemini/antigravity/brain/33e99043-f85e-41f9-8cac-a176287c0fba/.system_generated/logs/transcript_full.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for s in [12, 22, 24, 186, 188]:
    if s < len(lines):
        d = json.loads(lines[s])
        print(f"=== STEP {s} ===")
        print(str(d.get('content', ''))[:500])

