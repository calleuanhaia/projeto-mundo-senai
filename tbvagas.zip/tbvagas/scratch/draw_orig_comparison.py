import cv2
import numpy as np

img = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')

orig_8_spots = [
  {"id": "PCD-01", "points": [[115, 780], [305, 780], [330, 715], [150, 715]]},
  {"id": "VAGA-02", "points": [[150, 715], [330, 715], [350, 670], [178, 670]]},
  {"id": "VAGA-03", "points": [[178, 670], [350, 670], [365, 635], [198, 635]]},
  {"id": "VAGA-04", "points": [[198, 635], [365, 635], [378, 608], [215, 608]]},
  {"id": "VAGA-05", "points": [[780, 715], [1010, 715], [1000, 770], [765, 770]]},
  {"id": "VAGA-06", "points": [[765, 770], [1000, 770], [990, 830], [750, 830]]},
  {"id": "VAGA-07", "points": [[795, 670], [1018, 670], [1010, 715], [780, 715]]},
  {"id": "VAGA-08", "points": [[805, 635], [1025, 635], [1018, 670], [795, 670]]}
]

# Draw original 8 spots
img_orig = img.copy()
for s in orig_8_spots:
    pts = np.array(s['points'], np.int32)
    cv2.polylines(img_orig, [pts], True, (0, 255, 0), 2)
    cv2.putText(img_orig, s['id'], (pts[0][0], pts[0][1]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

cv2.imwrite('scratch/orig_8_spots_on_gemini.jpg', img_orig)
print("Saved orig_8_spots_on_gemini.jpg")

# Also on estacionamento_noturno.jpg
img_noturno = cv2.imread('data/images/estacionamento_noturno.jpg')
img_not_draw = img_noturno.copy()
for s in orig_8_spots:
    pts = np.array(s['points'], np.int32)
    cv2.polylines(img_not_draw, [pts], True, (0, 255, 0), 2)
    cv2.putText(img_not_draw, s['id'], (pts[0][0], pts[0][1]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
cv2.imwrite('scratch/orig_8_spots_on_noturno.jpg', img_not_draw)
print("Saved orig_8_spots_on_noturno.jpg")

