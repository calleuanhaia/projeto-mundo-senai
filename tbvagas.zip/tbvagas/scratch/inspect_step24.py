import json

with open('C:/Users/calleu_anhaia/.gemini/antigravity/brain/33e99043-f85e-41f9-8cac-a176287c0fba/.system_generated/logs/transcript_full.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

d = json.loads(lines[24])
print(d.get('content'))

