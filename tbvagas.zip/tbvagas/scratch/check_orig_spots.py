import cv2
import numpy as np

img1 = cv2.imread('data/images/estacionamento_noturno.jpg')
img_gemini = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')

orig_8_spots = [
  {
    "id": "PCD-01",
    "points": [[115, 780], [305, 780], [330, 715], [150, 715]]
  },
  {
    "id": "VAGA-02",
    "points": [[150, 715], [330, 715], [350, 670], [178, 670]]
  },
  {
    "id": "VAGA-03",
    "points": [[178, 670], [350, 670], [365, 635], [198, 635]]
  },
  {
    "id": "VAGA-04",
    "points": [[198, 635], [365, 635], [378, 608], [215, 608]]
  },
  {
    "id": "VAGA-05",
    "points": [[780, 715], [1010, 715], [1000, 770], [765, 770]]
  },
  {
    "id": "VAGA-06",
    "points": [[765, 770], [1000, 770], [990, 830], [750, 830]]
  },
  {
    "id": "VAGA-07",
    "points": [[795, 670], [1018, 670], [1010, 715], [780, 715]]
  },
  {
    "id": "VAGA-08",
    "points": [[805, 635], [1025, 635], [1018, 670], [795, 670]]
  }
]

# Check the pixel colors under orig_8_spots on both images
for s in orig_8_spots:
    pts = np.array(s['points'], np.int32)
    mask = np.zeros(img1.shape[:2], np.uint8)
    cv2.fillPoly(mask, [pts], 255)
    mean1 = cv2.mean(img1, mask=mask)[:3]
    mean2 = cv2.mean(img_gemini, mask=mask)[:3]
    print(f"{s['id']}: noturno BGR={mean1}, gemini BGR={mean2}")

