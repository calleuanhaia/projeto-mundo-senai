import cv2
import numpy as np

img1 = cv2.imread('data/images/estacionamento_noturno.jpg')
img2 = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')
diff = cv2.absdiff(img1, img2)
gray_diff = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
_, thresh = cv2.threshold(gray_diff, 30, 255, cv2.THRESH_BINARY)
non_zero = cv2.findNonZero(thresh)
if non_zero is not None:
    x, y, w, h = cv2.boundingRect(non_zero)
    print(f"Bounding box of differences: x={x}, y={y}, w={w}, h={h}")
    print("Number of differing pixels:", cv2.countNonZero(thresh))
else:
    print("Identical!")

