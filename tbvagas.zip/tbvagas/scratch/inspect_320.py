import json

with open('C:/Users/calleu_anhaia/.gemini/antigravity/brain/33e99043-f85e-41f9-8cac-a176287c0fba/.system_generated/logs/transcript_full.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for s in range(320, 360):
    if s < len(lines):
        d = json.loads(lines[s])
        if d.get('type') == 'PLANNER_RESPONSE':
            for tc in d.get('tool_calls', []):
                print(f"Step {s}: {tc['name']} -> {tc['args'].get('CommandLine', '') or tc['args'].get('Path', '')}")

