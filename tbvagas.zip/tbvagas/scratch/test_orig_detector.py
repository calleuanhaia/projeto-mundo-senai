import sys
sys.path.insert(0, '.')
import cv2
import json
from core.detector import ParkingDetector
from core.spot_manager import ParkingSpot

orig_8_spots_data = [
  {"id": "PCD-01", "label": "PCD 01", "type": "PCD", "points": [[115, 780], [305, 780], [330, 715], [150, 715]]},
  {"id": "VAGA-02", "label": "Vaga 02", "type": "Normal", "points": [[150, 715], [330, 715], [350, 670], [178, 670]]},
  {"id": "VAGA-03", "label": "Vaga 03", "type": "Normal", "points": [[178, 670], [350, 670], [365, 635], [198, 635]]},
  {"id": "VAGA-04", "label": "Vaga 04", "type": "Normal", "points": [[198, 635], [365, 635], [378, 608], [215, 608]]},
  {"id": "VAGA-08", "label": "Vaga 08", "type": "Normal", "points": [[805, 635], [1025, 635], [1018, 670], [795, 670]]},
  {"id": "VAGA-07", "label": "Vaga 07", "type": "Normal", "points": [[795, 670], [1018, 670], [1010, 715], [780, 715]]},
  {"id": "VAGA-05", "label": "Vaga 05", "type": "Normal", "points": [[780, 715], [1010, 715], [1000, 770], [765, 770]]},
  {"id": "VAGA-06", "label": "Vaga 06", "type": "Normal", "points": [[765, 770], [1000, 770], [990, 830], [750, 830]]}
]

spots = [ParkingSpot.from_dict(s) for s in orig_8_spots_data]
detector = ParkingDetector()

for img_name in ['Gemini_Generated_Image_12iqg312iqg312iq.jpg', 'estacionamento_noturno.jpg', 'estacionamento_noturno_com_carros.jpg']:
    img = cv2.imread(f'data/images/{img_name}')
    res = detector.analyze_spots(img, spots, mode='hybrid')
    print(f"\n--- {img_name} ---")
    print(f"Total: {res['total_spots']}, Free: {res['free_spots']}, Occ: {res['occupied_spots']}")
    for s in res['spots']:
        print(f"  {s['spot_id']} ({s['label']}): {s['status']} (score={s['score']:.1f}, veh={s.get('vehicle_info') is not None})")
