import cv2
import os

files = os.listdir('data/images')
for f in files:
    img = cv2.imread(os.path.join('data/images', f))
    if img is not None:
        h, w, c = img.shape
        # get average color of center region
        center_color = img[h//3:2*h//3, w//3:2*w//3].mean(axis=(0,1))
        # get bottom color
        bottom_color = img[2*h//3:, :].mean(axis=(0,1))
        print(f"{f}: shape=({w}x{h}), center_bgr=({center_color[0]:.1f}, {center_color[1]:.1f}, {center_color[2]:.1f}), bottom_bgr=({bottom_color[0]:.1f}, {bottom_color[1]:.1f}, {bottom_color[2]:.1f})")

