import cv2
import json
import numpy as np

img = cv2.imread('data/images/Gemini_Generated_Image_12iqg312iqg312iq.jpg')
spots = json.load(open('data/spots.json'))['Gemini_Generated_Image_12iqg312iqg312iq.jpg']

img_draw = img.copy()
for s in spots:
    pts = np.array(s['points'], np.int32)
    cv2.polylines(img_draw, [pts], True, (0, 0, 255), 2)
    cv2.putText(img_draw, s['id'], (pts[0][0], pts[0][1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)

cv2.imwrite('scratch/current_spots_drawn.jpg', img_draw)
print("Saved current_spots_drawn.jpg")

