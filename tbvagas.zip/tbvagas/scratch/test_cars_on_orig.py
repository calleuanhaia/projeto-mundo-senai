import cv2
import numpy as np
from ultralytics import YOLO

orig_8_spots = [
  {"id": "PCD-01", "label": "PCD 01", "type": "PCD", "points": [[115, 780], [305, 780], [330, 715], [150, 715]]},
  {"id": "VAGA-02", "label": "Vaga 02", "type": "Normal", "points": [[150, 715], [330, 715], [350, 670], [178, 670]]},
  {"id": "VAGA-03", "label": "Vaga 03", "type": "Normal", "points": [[178, 670], [350, 670], [365, 635], [198, 635]]},
  {"id": "VAGA-04", "label": "Vaga 04", "type": "Normal", "points": [[198, 635], [365, 635], [378, 608], [215, 608]]},
  {"id": "VAGA-08", "label": "Vaga 08", "type": "Normal", "points": [[805, 635], [1025, 635], [1018, 670], [795, 670]]},
  {"id": "VAGA-07", "label": "Vaga 07", "type": "Normal", "points": [[795, 670], [1018, 670], [1010, 715], [780, 715]]},
  {"id": "VAGA-05", "label": "Vaga 05", "type": "Normal", "points": [[780, 715], [1010, 715], [1000, 770], [765, 770]]},
  {"id": "VAGA-06", "label": "Vaga 06", "type": "Normal", "points": [[765, 770], [1000, 770], [990, 830], [750, 830]]}
]

model = YOLO('yolov8n.pt')
img = cv2.imread('data/images/estacionamento_noturno_com_carros.jpg')
results = model(img, conf=0.25, classes=[2, 3, 5, 7])

vehicles = []
for r in results:
    for box in r.boxes:
        xyxy = box.xyxy[0].cpu().numpy().astype(int)
        conf = float(box.conf[0])
        cls = int(box.cls[0])
        vehicles.append({'box': xyxy, 'conf': conf, 'cls': cls})
        print(f"Vehicle box: {xyxy}, conf: {conf:.2f}")

# Check intersections
for v in vehicles:
    vx1, vy1, vx2, vy2 = v['box']
    v_poly = np.array([[vx1, vy1], [vx2, vy1], [vx2, vy2], [vx1, vy2]], np.int32)
    for s in orig_8_spots:
        s_poly = np.array(s['points'], np.int32)
        # mask overlap
        m_v = np.zeros(img.shape[:2], np.uint8)
        m_s = np.zeros(img.shape[:2], np.uint8)
        cv2.fillPoly(m_v, [v_poly], 255)
        cv2.fillPoly(m_s, [s_poly], 255)
        inter = cv2.countNonZero(cv2.bitwise_and(m_v, m_s))
        s_area = cv2.countNonZero(m_s)
        pct = (inter / s_area) * 100
        if inter > 100:
            print(f"Vehicle at y={vy1}-{vy2} overlaps {s['id']}: inter={inter}px ({pct:.1f}%)")

