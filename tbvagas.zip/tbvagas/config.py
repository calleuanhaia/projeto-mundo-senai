"""
Configurações Globais do Sistema de Monitoramento e Mapeamento de Vagas
"""

import os
from pathlib import Path

# Diretórios base
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
IMAGES_DIR = DATA_DIR / "images"
SPOTS_FILE = DATA_DIR / "spots.json"

# Garantir existência de diretórios essenciais
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# Tipos de arquivos de imagem permitidos
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# Parâmetros Padrão do Pipeline OpenCV
OPENCV_DEFAULT_CONFIG = {
    # Tamanho do Kernel Gaussian Blur
    "blur_kernel": 5,
    # Parâmetros Adaptive Threshold
    "adaptive_block_size": 25,
    "adaptive_c": 16,
    # Dilatação morfológica
    "dilate_kernel_size": 3,
    "dilate_iterations": 1,
    # Canny Edge
    "canny_low": 50,
    "canny_high": 150,
    # Limiares de classificação (Thresholds de Ocupação)
    # Proporção de pixels não-nulos no threshold binário (0.0 a 1.0)
    "pixel_ratio_threshold": 0.015,
    # Proporção de bordas Canny (0.0 a 1.0)
    "edge_ratio_threshold": 0.012,
    # Desvio padrão de intensidade de cinza
    "std_dev_threshold": 28.0,
    # Pontuação ponderada combinada para decisão final (0 a 100)
    "occupancy_threshold_score": 30.0,
    # Pesos do score: pixel ratio, edge ratio, std dev
    "weights": {
        "pixel": 40.0,
        "edge": 40.0,
        "std": 20.0
    }
}

# Configurações do Servidor Web
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5000
DEBUG_MODE = True
