"""
CLI - Analisador de Vagas de Estacionamento via Linha de Comando (OpenCV)
Permite executar a detecção diretamente pelo terminal, gerar relatórios e exportar imagens anotadas.
"""

import argparse
import sys
from pathlib import Path
import cv2

from core.detector import ParkingDetector
from core.spot_manager import SpotManager
from core.image_manager import ImageManager


def run_cli():
    parser = argparse.ArgumentParser(
        description="TBVAGAS CLI: Analisador de Vagas de Estacionamento com OpenCV e IA"
    )
    parser.add_argument(
        "--image",
        type=str,
        default="estacionamento_dia_cam04.jpg",
        help="Nome ou caminho da imagem a analisar"
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=["opencv", "yolo", "hybrid"],
        default="hybrid",
        help="Modo de detecção: 'opencv' (texturas/bordas), 'yolo' (IA) ou 'hybrid' (ambos)"
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=None,
        help="Sensibilidade personalizada de ocupação (score mínimo)"
    )
    parser.add_argument(
        "--save-output",
        type=str,
        default=None,
        help="Caminho para salvar a imagem anotada gerada (ex: resultado.jpg)"
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Abre janela interativa cv2.imshow (pressione qualquer tecla para fechar)"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Executa análise em lote de todas as imagens cadastradas"
    )
    parser.add_argument(
        "--metrics",
        action="store_true",
        help="Exibe métricas detalhadas de pixels, bordas e desvio padrão para cada vaga"
    )

    args = parser.parse_args()

    image_manager = ImageManager()
    spot_manager = SpotManager()
    detector = ParkingDetector()

    if args.all:
        images_list = image_manager.list_images()
        print(f"\n=======================================================")
        print(f"  TBVAGAS: ANÁLISE EM LOTE ({len(images_list)} IMAGENS)")
        print(f"=======================================================\n")

        for img_info in images_list:
            filename = img_info["filename"]
            img = image_manager.read_image(filename)
            if img is None:
                continue

            spots = spot_manager.get_spots(filename)
            res = detector.analyze_spots(img, spots, mode=args.mode, custom_threshold=args.threshold)
            print(f"[*] {filename} ({img_info['width']}x{img_info['height']}):")
            print(f"    - Total: {res['total_spots']} vagas")
            print(f"    - Livres: {res['free_spots']} | Ocupadas: {res['occupied_spots']}")
            print(f"    - Ocupação: {res['occupancy_rate']}% | Tempo: {res['inference_time_ms']}ms\n")
        return

    # Imagem única
    target_img = args.image
    img = None
    if Path(target_img).exists():
        img = cv2.imread(target_img)
        filename = Path(target_img).name
    else:
        img = image_manager.read_image(target_img)
        filename = target_img

    if img is None:
        print(f"[ERRO] Não foi possível carregar a imagem: {target_img}")
        sys.exit(1)

    spots = spot_manager.get_spots(filename)
    if not spots:
        print(f"[AVISO] Nenhuma vaga mapeada especificamente para '{filename}'. Usando vagas do template padrão.")
        spots = spot_manager.get_spots("")

    print(f"\n=======================================================")
    print(f"  TBVAGAS: ANÁLISE DE ESTACIONAMENTO ({filename})")
    print(f"  Modo: {args.mode.upper()} | Vagas Mapeadas: {len(spots)}")
    print(f"=======================================================\n")

    result = detector.analyze_spots(img, spots, mode=args.mode, custom_threshold=args.threshold)

    print(f"Resultados Consolidados:")
    print(f"  • Total de Vagas:     {result['total_spots']}")
    print(f"  • Vagas Livres:       {result['free_spots']} (Verde)")
    print(f"  • Vagas Ocupadas:     {result['occupied_spots']} (Vermelho)")
    print(f"  • Taxa de Ocupação:   {result['occupancy_rate']}%")
    print(f"  • Tempo de Inferência:{result['inference_time_ms']} ms\n")

    print("Detalhamento por Vaga:")
    for s in result["spots"]:
        status_symbol = "[X]" if s["is_occupied"] else "[OK]"
        status_str = "OCUPADA" if s["is_occupied"] else "LIVRE  "
        print(f"  {status_symbol} {s['label']:<15} | Tipo: {s['type']:<7} | Status: {status_str} | Score: {s['score']}")
        if args.metrics:
            m = s["metrics"]
            print(f"      -> Pixels: {m['pixel_count']} ({m['pixel_ratio']:.3%}) | Bordas: {m['edge_count']} ({m['edge_ratio']:.3%}) | Desvio: {m['std_dev']}")

    # Gerar imagem anotada
    annotated = detector.annotate_image(img, result, show_metrics=args.metrics)

    output_path = args.save_output or f"resultado_{Path(filename).stem}.jpg"
    cv2.imwrite(output_path, annotated)
    print(f"\n[+] Imagem com overlay de vagas salva em: {output_path}")

    if args.show:
        try:
            cv2.imshow(f"TBVagas - {filename}", annotated)
            print("[*] Pressione qualquer tecla na janela da imagem para sair...")
            cv2.waitKey(0)
            cv2.destroyAllWindows()
        except Exception as e:
            print(f"[Aviso] cv2.imshow não pôde abrir display: {e}")


if __name__ == "__main__":
    run_cli()
