"""
Módulo de Gerenciamento e Geometria de Vagas de Estacionamento
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import cv2
import numpy as np

from config import SPOTS_FILE


class ParkingSpot:
    """Representa uma vaga de estacionamento delimitada por um polígono."""

    def __init__(
        self,
        spot_id: str,
        points: List[List[int]],
        label: Optional[str] = None,
        spot_type: str = "Normal",
        image_name: Optional[str] = None
    ):
        self.id = spot_id
        self.points = points  # Lista de [x, y]
        self.label = label or spot_id
        self.spot_type = spot_type
        self.image_name = image_name

    @property
    def np_points(self) -> np.ndarray:
        """Retorna os pontos em formato numpy array para uso com cv2."""
        return np.array(self.points, dtype=np.int32)

    @property
    def bounding_box(self) -> Tuple[int, int, int, int]:
        """Calcula a bounding box retangular (x, y, w, h) da vaga."""
        x, y, w, h = cv2.boundingRect(self.np_points)
        return int(x), int(y), int(w), int(h)

    @property
    def area(self) -> float:
        """Calcula a área em pixels do polígono da vaga."""
        return float(cv2.contourArea(self.np_points))

    @property
    def center(self) -> Tuple[int, int]:
        """Calcula o centroide da vaga."""
        m = cv2.moments(self.np_points)
        if m["m00"] != 0:
            cx = int(m["m10"] / m["m00"])
            cy = int(m["m01"] / m["m00"])
            return cx, cy
        # Fallback para média simples
        pts = np.array(self.points)
        return int(pts[:, 0].mean()), int(pts[:, 1].mean())

    def to_dict(self) -> Dict[str, Any]:
        """Serialização para dicionário/JSON."""
        return {
            "id": self.id,
            "label": self.label,
            "type": self.spot_type,
            "points": self.points,
            "image_name": self.image_name
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ParkingSpot":
        return cls(
            spot_id=data["id"],
            points=data["points"],
            label=data.get("label"),
            spot_type=data.get("type", "Normal"),
            image_name=data.get("image_name")
        )


class SpotManager:
    """Gerenciador central de persistência e manipulação de vagas."""

    def __init__(self, storage_path: Path = SPOTS_FILE):
        self.storage_path = Path(storage_path)
        self.spots_by_image: Dict[str, List[ParkingSpot]] = {}
        self.load()

    def load(self) -> None:
        """Carrega todas as vagas salvas do arquivo JSON."""
        if not self.storage_path.exists():
            self.spots_by_image = {}
            return

        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
                self.spots_by_image = {}
                for img_name, spots_list in raw_data.items():
                    self.spots_by_image[img_name] = [
                        ParkingSpot.from_dict({**s, "image_name": img_name})
                        for s in spots_list
                    ]
        except Exception as e:
            print(f"[SpotManager] Erro ao carregar vagas: {e}")
            self.spots_by_image = {}

    def save(self) -> None:
        """Salva todas as vagas no arquivo JSON de forma atômica."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        raw_data = {}
        for img_name, spots in self.spots_by_image.items():
            raw_data[img_name] = [s.to_dict() for s in spots]

        temp_file = self.storage_path.with_suffix(".tmp")
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(raw_data, f, indent=2, ensure_ascii=False)
        temp_file.replace(self.storage_path)

    def get_spots(self, image_name: str) -> List[ParkingSpot]:
        """Retorna a lista de vagas associadas a uma imagem específica."""
        # Se houver mapeamento específico para a imagem, retorna
        if image_name in self.spots_by_image:
            return self.spots_by_image[image_name]
        # Se não houver, tenta usar o primeiro conjunto disponível como template padrão
        if self.spots_by_image:
            first_key = next(iter(self.spots_by_image))
            return self.spots_by_image[first_key]
        return []

    def set_spots(self, image_name: str, spots_data: List[Dict[str, Any]]) -> List[ParkingSpot]:
        """Atualiza a lista de vagas para uma imagem e salva."""
        spots = []
        for i, s in enumerate(spots_data):
            spot_id = s.get("id") or f"VAGA-{i+1:02d}"
            label = s.get("label") or spot_id
            spot_type = s.get("type", "Normal")
            points = s["points"]
            spots.append(ParkingSpot(
                spot_id=spot_id,
                points=points,
                label=label,
                spot_type=spot_type,
                image_name=image_name
            ))
        self.spots_by_image[image_name] = spots
        self.save()
        return spots

    def create_mask_for_spot(self, shape: Tuple[int, int], spot: ParkingSpot) -> np.ndarray:
        """Gera máscara binária uint8 (0 e 255) do polígono da vaga."""
        mask = np.zeros(shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [spot.np_points], 255)
        return mask
