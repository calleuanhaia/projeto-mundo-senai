"""
Módulo de Gerenciamento de Imagens e Armazenamento
"""

import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Any
import cv2
import numpy as np

from config import IMAGES_DIR, ALLOWED_EXTENSIONS


FRIENDLY_NAMES = {
    "Gemini_Generated_Image_12iqg312iqg312iq.jpg": "Noturno Demarcado (Vazio)",
    "estacionamento_noturno_com_carros.jpg": "Noturno com Carros (Ocupado)",
    "Gemini_Generated_Image_893v4e893v4e893v.jpg": "Noturno com Carros (IA)",
    "estacionamento_dia_cam04.jpg": "Câmera 04 (Diurno)",
    "estacionamento_noturno.jpg": "Noturno Original"
}


class ImageManager:
    """Gerencia a galeria de imagens de estacionamento e uploads."""

    def __init__(self, images_dir: Path = IMAGES_DIR):
        self.images_dir = Path(images_dir)
        self.images_dir.mkdir(parents=True, exist_ok=True)

    def list_images(self) -> List[Dict[str, Any]]:
        """Lista todas as imagens válidas no diretório com metadados."""
        images = []
        for file in sorted(self.images_dir.iterdir()):
            if file.is_file() and file.suffix.lower() in ALLOWED_EXTENSIONS:
                stat = file.stat()
                # Obter resolução rapidamente
                try:
                    img = cv2.imread(str(file))
                    if img is not None:
                        h, w, c = img.shape
                    else:
                        w, h = 0, 0
                except Exception:
                    w, h = 0, 0

                display_name = FRIENDLY_NAMES.get(file.name, file.name)

                images.append({
                    "filename": file.name,
                    "display_name": display_name,
                    "size_bytes": stat.st_size,
                    "modified": stat.st_mtime,
                    "width": w,
                    "height": h
                })
        return images

    def get_image_path(self, filename: str) -> Optional[Path]:
        """Retorna o caminho seguro para um arquivo de imagem."""
        # Evitar directory traversal
        safe_name = Path(filename).name
        target = self.images_dir / safe_name
        if target.exists() and target.is_file():
            return target
        return None

    def read_image(self, filename: str) -> Optional[np.ndarray]:
        """Carrega a imagem em formato BGR do OpenCV."""
        path = self.get_image_path(filename)
        if not path:
            return None
        return cv2.imread(str(path))

    def save_image(self, filename: str, file_bytes: bytes) -> str:
        """Salva uma nova imagem enviada pelo usuário com nome seguro."""
        safe_name = Path(filename).name
        suffix = Path(safe_name).suffix.lower()
        if suffix not in ALLOWED_EXTENSIONS:
            raise ValueError(f"Extensão não suportada: {suffix}")

        # Se já existir, adiciona sufixo numérico
        target = self.images_dir / safe_name
        counter = 1
        stem = Path(safe_name).stem
        while target.exists():
            target = self.images_dir / f"{stem}_{counter}{suffix}"
            counter += 1

        with open(target, "wb") as f:
            f.write(file_bytes)

        # Validar integridade lendo com OpenCV
        test_img = cv2.imread(str(target))
        if test_img is None:
            target.unlink(missing_ok=True)
            raise ValueError("Arquivo corrompido ou imagem inválida.")

        return target.name

    def delete_image(self, filename: str) -> bool:
        """Remove uma imagem do armazenamento."""
        path = self.get_image_path(filename)
        if path and path.exists():
            path.unlink()
            return True
        return False
