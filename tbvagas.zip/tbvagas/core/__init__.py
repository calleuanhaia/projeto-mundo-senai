"""
Pacote core para análise de vagas com OpenCV
"""

from core.detector import ParkingDetector
from core.spot_manager import ParkingSpot, SpotManager
from core.image_manager import ImageManager

__all__ = ["ParkingDetector", "ParkingSpot", "SpotManager", "ImageManager"]
