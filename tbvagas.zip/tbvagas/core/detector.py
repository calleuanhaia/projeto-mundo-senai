"""
Módulo de Detecção de Ocupação de Vagas de Estacionamento via OpenCV e IA
"""

import time
from typing import Dict, List, Optional, Tuple, Any
import cv2
import numpy as np

from config import OPENCV_DEFAULT_CONFIG
from core.spot_manager import ParkingSpot

# Tentar carregar YOLO se disponível
YOLO_AVAILABLE = False
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except Exception:
    YOLO_AVAILABLE = False


class ParkingDetector:
    """Motor de processamento de visão computacional para detecção de vagas."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = {**OPENCV_DEFAULT_CONFIG, **(config or {})}
        self.yolo_model = None
        self._yolo_loaded = False

    def _ensure_yolo(self):
        """Inicialização preguiçosa (lazy load) do modelo YOLOv8 nano."""
        if not self._yolo_loaded and YOLO_AVAILABLE:
            try:
                # Usa yolov8n (ultra leve e rápido)
                self.yolo_model = YOLO("yolov8n.pt")
                self._yolo_loaded = True
            except Exception as e:
                print(f"[ParkingDetector] Aviso: Não foi possível carregar YOLO: {e}")
                self._yolo_loaded = False

    def preprocess_image(self, bgr_image: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Aplica a esteira de pré-processamento OpenCV na imagem:
        - Escala de cinza
        - Filtro Gaussiano de redução de ruído
        - Adaptive Thresholding (invariante a iluminação)
        - Dilatação morfológica
        - Detecção de Bordas Canny
        """
        gray = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
        
        ksize = self.config["blur_kernel"]
        blur = cv2.GaussianBlur(gray, (ksize, ksize), 1)

        # Adaptive Threshold para isolar texturas e descontinuidades
        block_size = self.config["adaptive_block_size"]
        if block_size % 2 == 0:
            block_size += 1
        adaptive_thresh = cv2.adaptiveThreshold(
            blur,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            block_size,
            self.config["adaptive_c"]
        )

        # Dilatação morfológica para conectar componentes estruturais
        dilate_k = self.config["dilate_kernel_size"]
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (dilate_k, dilate_k))
        dilated = cv2.dilate(adaptive_thresh, kernel, iterations=self.config["dilate_iterations"])

        # Detecção de bordas estruturais Canny
        edges = cv2.Canny(blur, self.config["canny_low"], self.config["canny_high"])

        return {
            "gray": gray,
            "blur": blur,
            "thresh": adaptive_thresh,
            "dilated": dilated,
            "edges": edges
        }

    def analyze_spot_opencv(
        self,
        spot: ParkingSpot,
        preprocessed: Dict[str, np.ndarray],
        custom_threshold: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Analisa uma vaga individual utilizando métricas puras de OpenCV:
        - Densidade de pixels no threshold morfológico
        - Densidade de bordas Canny
        - Variância / Desvio padrão de luminância
        - Score ponderado final
        """
        h, w = preprocessed["gray"].shape[:2]
        spot_pts = spot.np_points

        # Criar máscara isolada do polígono da vaga
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.fillPoly(mask, [spot_pts], 255)

        area = spot.area
        if area <= 0:
            area = max(1.0, float(cv2.countNonZero(mask)))

        # Bounding box para recortar ROI e acelerar cálculo
        bx, by, bw, bh = spot.bounding_box
        bx = max(0, bx)
        by = max(0, by)
        bw = min(bw, w - bx)
        bh = min(bh, h - by)

        roi_mask = mask[by:by+bh, bx:bx+bw]
        roi_dilated = preprocessed["dilated"][by:by+bh, bx:bx+bw]
        roi_edges = preprocessed["edges"][by:by+bh, bx:bx+bw]
        roi_gray = preprocessed["gray"][by:by+bh, bx:bx+bw]

        # Contagem de pixels ativos dentro da máscara do polígono
        masked_thresh = cv2.bitwise_and(roi_dilated, roi_dilated, mask=roi_mask)
        pixel_count = int(cv2.countNonZero(masked_thresh))
        pixel_ratio = float(pixel_count / area)

        # Contagem de bordas ativas dentro do polígono
        masked_edges = cv2.bitwise_and(roi_edges, roi_edges, mask=roi_mask)
        edge_count = int(cv2.countNonZero(masked_edges))
        edge_ratio = float(edge_count / area)

        # Desvio padrão dos tons de cinza dentro da vaga
        mean_val, std_val = cv2.meanStdDev(roi_gray, mask=roi_mask)
        std_dev = float(std_val[0][0]) if std_val is not None else 0.0

        # Cálculo do Score Combinado
        weights = self.config.get("weights", {"pixel": 40.0, "edge": 40.0, "std": 20.0})
        score = (
            (pixel_ratio * 100.0 * (weights.get("pixel", 40.0) / 40.0)) +
            (edge_ratio * 100.0 * (weights.get("edge", 40.0) / 40.0)) +
            ((std_dev / 25.5) * (weights.get("std", 20.0) / 20.0))
        )

        base_threshold = (
            custom_threshold
            if custom_threshold is not None
            else self.config["occupancy_threshold_score"]
        )

        # Calibração adaptativa para vagas especiais (ex: PCD):
        # A pintura horizontal do pictograma de acessibilidade e faixas zebradas
        # adiciona bordas e contraste mesmo com a vaga desocupada.
        thresh_score = base_threshold + 35.0 if spot.spot_type == "PCD" else base_threshold

        is_occupied = score >= thresh_score

        return {
            "spot_id": spot.id,
            "label": spot.label,
            "type": spot.spot_type,
            "points": spot.points,
            "center": spot.center,
            "status": "ocupada" if is_occupied else "livre",
            "is_occupied": is_occupied,
            "score": round(score, 2),
            "threshold": thresh_score,
            "metrics": {
                "pixel_count": pixel_count,
                "pixel_ratio": round(pixel_ratio, 5),
                "edge_count": edge_count,
                "edge_ratio": round(edge_ratio, 5),
                "std_dev": round(std_dev, 2),
                "area": round(area, 1)
            }
        }

    def detect_vehicles_yolo(self, bgr_image: np.ndarray) -> List[Dict[str, Any]]:
        """Executa inferência YOLO para detectar veículos na imagem."""
        self._ensure_yolo()
        if not self.yolo_model:
            return []

        # Classes veiculares do COCO: 2: car, 3: motorcycle, 5: bus, 7: truck
        vehicle_classes = {2: "carro", 3: "moto", 5: "onibus", 7: "caminhao"}
        try:
            results = self.yolo_model(bgr_image, verbose=False, conf=0.25)
            detections = []
            for r in results:
                boxes = r.boxes
                for box in boxes:
                    cls_id = int(box.cls[0].item())
                    if cls_id in vehicle_classes:
                        xyxy = box.xyxy[0].tolist()
                        conf = float(box.conf[0].item())
                        detections.append({
                            "class": vehicle_classes[cls_id],
                            "confidence": round(conf, 3),
                            "box": [int(v) for v in xyxy]  # [x1, y1, x2, y2]
                        })
            return detections
        except Exception as e:
            print(f"[ParkingDetector] Erro durante inferência YOLO: {e}")
            return []

    def analyze_spots(
        self,
        bgr_image: np.ndarray,
        spots: List[ParkingSpot],
        mode: str = "opencv",
        custom_threshold: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Executa a análise completa de um conjunto de vagas na imagem.
        Modos disponíveis:
        - 'opencv': Método clássico baseado em processamento de imagem e texturas.
        - 'yolo': Detecção profunda de objetos com YOLOv8.
        - 'hybrid': Fusão inteligente de OpenCV + YOLO.
        """
        start_time = time.time()
        preprocessed = self.preprocess_image(bgr_image)
        
        yolo_detections = []
        if mode in ("yolo", "hybrid") and YOLO_AVAILABLE:
            yolo_detections = self.detect_vehicles_yolo(bgr_image)

        # -------------------------------------------------------------
        # REGRA DE OURO: "Apenas um carro por vaga" (1-to-1 Bipartite Matching)
        # Um veículo não pode ocupar múltiplas vagas simultaneamente.
        # -------------------------------------------------------------
        spot_vehicle_matches: Dict[str, Dict[str, Any]] = {}
        if mode in ("yolo", "hybrid") and yolo_detections:
            valid_vehicles = [
                v for v in yolo_detections
                if v.get("confidence", 0) >= 0.35 and v.get("class") in ("carro", "caminhao", "onibus", "moto")
            ]

            h_img, w_img = bgr_image.shape[:2]
            candidates = []

            for vi, veh in enumerate(valid_vehicles):
                x1, y1, x2, y2 = veh["box"]
                vw = x2 - x1
                vh = y2 - y1
                # Ponto de contato dos pneus no solo (centro da base do veículo)
                wheel_x = (x1 + x2) // 2
                wheel_y = int(y2 - 0.15 * vh)

                mask_veh = np.zeros((h_img, w_img), dtype=np.uint8)
                cv2.rectangle(mask_veh, (x1, y1), (x2, y2), 255, -1)

                for si, s in enumerate(spots):
                    mask_spot = np.zeros((h_img, w_img), dtype=np.uint8)
                    cv2.fillPoly(mask_spot, [s.np_points], 255)

                    inter = cv2.countNonZero(cv2.bitwise_and(mask_veh, mask_spot))
                    if inter > 250:
                        overlap_pct = inter / max(1.0, s.area)
                        wheel_in = cv2.pointPolygonTest(s.np_points, (float(wheel_x), float(wheel_y)), False) >= 0

                        # Aceita se a base do carro toca a vaga ou se há sobreposição representativa (>= 20%)
                        if overlap_pct >= 0.20 or wheel_in:
                            # Prioridade máxima se os pneus estiverem geometricamente dentro do polígono
                            score_prio = overlap_pct + (2.0 if wheel_in else 0.0)
                            candidates.append({
                                "score_prio": score_prio,
                                "vi": vi,
                                "si": si,
                                "spot_id": s.id,
                                "vehicle": veh,
                                "overlap_pct": round(overlap_pct * 100.0, 1),
                                "wheel_in": wheel_in
                            })

            # Ordenar candidatos da maior sobreposição/aderência para a menor
            candidates.sort(key=lambda c: c["score_prio"], reverse=True)

            assigned_vehicles = set()
            assigned_spots = set()

            for c in candidates:
                vi = c["vi"]
                si = c["si"]
                if vi not in assigned_vehicles and si not in assigned_spots:
                    assigned_vehicles.add(vi)
                    assigned_spots.add(si)
                    spot_vehicle_matches[c["spot_id"]] = c["vehicle"]

        results = []
        occupied_count = 0

        for spot in spots:
            spot_res = self.analyze_spot_opencv(spot, preprocessed, custom_threshold)
            matched_vehicle = spot_vehicle_matches.get(spot.id)

            if mode == "yolo":
                spot_res["is_occupied"] = matched_vehicle is not None
                spot_res["status"] = "ocupada" if spot_res["is_occupied"] else "livre"
                if matched_vehicle:
                    spot_res["vehicle_info"] = matched_vehicle

            elif mode == "hybrid":
                if matched_vehicle:
                    # Veículo associado exclusivamente a esta vaga (regra de 1 carro por vaga)
                    spot_res["is_occupied"] = True
                    spot_res["status"] = "ocupada"
                    spot_res["vehicle_info"] = matched_vehicle
                else:
                    # Nenhum veículo atribuído a esta vaga pelo YOLO
                    # Só considera ocupada se OpenCV registrar textura massiva anormal (obstáculo não-veicular)
                    override_threshold = 85.0 if spot.spot_type == "PCD" else 55.0
                    if spot_res["score"] >= override_threshold:
                        spot_res["is_occupied"] = True
                        spot_res["status"] = "ocupada"
                    else:
                        spot_res["is_occupied"] = False
                        spot_res["status"] = "livre"

            if spot_res["is_occupied"]:
                occupied_count += 1
            results.append(spot_res)

        total_spots = len(spots)
        free_spots = total_spots - occupied_count
        occupancy_rate = round((occupied_count / total_spots * 100.0), 1) if total_spots > 0 else 0.0
        elapsed_ms = round((time.time() - start_time) * 1000.0, 1)

        return {
            "total_spots": total_spots,
            "free_spots": free_spots,
            "occupied_spots": occupied_count,
            "occupancy_rate": occupancy_rate,
            "inference_time_ms": elapsed_ms,
            "mode": mode,
            "spots": results,
            "yolo_detections": yolo_detections
        }

    def annotate_image(
        self,
        bgr_image: np.ndarray,
        analysis_result: Dict[str, Any],
        show_metrics: bool = False
    ) -> np.ndarray:
        """
        Renderiza um overlay visual premium na imagem com OpenCV:
        - Polígonos translúcidos (Verde = Livre, Vermelho = Ocupada)
        - Bordas nítidas anti-aliasing
        - Badges de identificação de vagas de alto contraste
        - HUD superior com resumo estatístico executivo
        """
        output = bgr_image.copy()
        overlay = bgr_image.copy()

        # Cores BGR
        COLOR_FREE = (46, 204, 113)      # Verde Esmeralda
        COLOR_OCCUPIED = (60, 76, 231)   # Vermelho Coral
        COLOR_BORDER_FREE = (39, 174, 96)
        COLOR_BORDER_OCCUPIED = (40, 50, 192)

        # 1. Preenchimento translúcido das vagas
        for item in analysis_result.get("spots", []):
            pts = np.array(item["points"], dtype=np.int32)
            color = COLOR_OCCUPIED if item["is_occupied"] else COLOR_FREE
            cv2.fillPoly(overlay, [pts], color)

        # Mesclar overlay translúcido com alpha = 0.35
        alpha = 0.35
        cv2.addWeighted(overlay, alpha, output, 1 - alpha, 0, output)

        # 2. Desenhar bordas nítidas e rótulos
        for item in analysis_result.get("spots", []):
            pts = np.array(item["points"], dtype=np.int32)
            is_occ = item["is_occupied"]
            border_color = COLOR_BORDER_OCCUPIED if is_occ else COLOR_BORDER_FREE

            # Linha de contorno externa
            cv2.polylines(output, [pts], isClosed=True, color=border_color, thickness=2, lineType=cv2.LINE_AA)

            # Rótulo centralizado
            cx, cy = item["center"]
            label_text = f"{item['label']}: {'OCUPADA' if is_occ else 'LIVRE'}"
            if show_metrics:
                label_text += f" ({item['score']:.1f})"

            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.45
            thickness = 1
            (tw, th), baseline = cv2.getTextSize(label_text, font, font_scale, thickness)

            # Pílula de fundo para o texto
            px1 = cx - (tw // 2) - 6
            py1 = cy - (th // 2) - 4
            px2 = cx + (tw // 2) + 6
            py2 = cy + (th // 2) + 6

            badge_color = (25, 25, 30)
            cv2.rectangle(output, (px1, py1), (px2, py2), badge_color, -1)
            cv2.rectangle(output, (px1, py1), (px2, py2), border_color, 1, cv2.LINE_AA)

            text_color = (255, 255, 255)
            cv2.putText(
                output,
                label_text,
                (cx - (tw // 2), cy + (th // 2) - 1),
                font,
                font_scale,
                text_color,
                thickness,
                lineType=cv2.LINE_AA
            )

        # 3. Bounding boxes dos veículos detectados pelo YOLO
        for veh in analysis_result.get("yolo_detections", []):
            x1, y1, x2, y2 = veh["box"]
            cv2.rectangle(output, (x1, y1), (x2, y2), (212, 182, 6), 2, cv2.LINE_AA)
            conf_pct = int(veh.get("confidence", 0) * 100)
            v_label = f"{veh.get('class', 'veiculo').upper()} {conf_pct}%"
            (vw, vh), _ = cv2.getTextSize(v_label, cv2.FONT_HERSHEY_SIMPLEX, 0.42, 1)
            cv2.rectangle(output, (x1, max(0, y1 - 20)), (x1 + vw + 8, y1), (25, 25, 30), -1)
            cv2.rectangle(output, (x1, max(0, y1 - 20)), (x1 + vw + 8, y1), (212, 182, 6), 1, cv2.LINE_AA)
            cv2.putText(output, v_label, (x1 + 4, max(14, y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (240, 240, 240), 1, cv2.LINE_AA)

        # 4. HUD Superior Moderno com Métricas Gerais
        h, w = output.shape[:2]
        hud_height = 54
        hud_bg = output[:hud_height, :].copy()
        cv2.rectangle(output, (0, 0), (w, hud_height), (18, 22, 28), -1)

        # Informações no cabeçalho
        total = analysis_result.get("total_spots", 0)
        free = analysis_result.get("free_spots", 0)
        occ = analysis_result.get("occupied_spots", 0)
        rate = analysis_result.get("occupancy_rate", 0.0)
        elapsed = analysis_result.get("inference_time_ms", 0.0)
        mode = analysis_result.get("mode", "opencv").upper()

        title_str = "TBVAGAS AI | MONITORAMENTO OPENCV"
        cv2.putText(output, title_str, (16, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)

        stats_str = f"TOTAL: {total}  |  LIVRES: {free}  |  OCUPADAS: {occ}  |  OCUPACAO: {rate}%  |  MODO: {mode}  |  {elapsed}ms"
        (sw, sh), _ = cv2.getTextSize(stats_str, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.putText(
            output,
            stats_str,
            (w - sw - 20, 32),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (200, 230, 255),
            1,
            cv2.LINE_AA
        )

        return output
